<?php

namespace HiFolks\Statistics\Exception;

use InvalidArgumentException;

class InvalidDataInputException extends InvalidArgumentException {}
